﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;   // required for database
using System.Data.SqlClient; // needed for sql server


namespace WebApplication7
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLSERV2014;AttachDbFilename=C:\Users\Manisha\Documents\Visual Studio 2010\Projects\WebApplication7\WebApplication7\App_Data\OCA.mdf;Integrated Security=True;User Instance=True");


        SqlDataAdapter da;
        DataSet ds;
        public int i, n;

        protected void Page_Load(object sender, EventArgs e)
        {

            da = new SqlDataAdapter("select * from Usertable", con);
            ds = new DataSet();
            da.Fill(ds, "Usertable");
            n = ds.Tables["Usertable"].Rows.Count;
            TextBox1.Focus();


        }

      

        protected void Button2_Click(object sender, EventArgs e)
        {
            string s = string.Format("http://www.google.co.in/search?q={0}", TextBox3.Text);
            Response.Redirect(s);
        }


        protected void Button3_Click(object sender, EventArgs e)
        {
            string s = string.Format("http://in.search.yahoo.com/search?q={0}", TextBox4.Text);
            Response.Redirect(s);
        }



        protected void btnLogin_Click(object sender, EventArgs e)
        {
            for (i = 0; i < n; i++)
            {
                if (TextBox1.Text == ds.Tables["Usertable"].Rows[i][0].ToString() && TextBox2.Text == ds.Tables["Usertable"].Rows[i][2].ToString())
                {
                    //Session["un"] = TextBox1.Text;
                    Session["un"] = ds.Tables["Usertable"].Rows[i][1].ToString();
                    Response.Redirect("FinalTest.aspx");
                }
                else if (TextBox1.Text == "Admin" || TextBox2.Text == "admin")
                {
                    Response.Redirect("EnterQuestions.aspx");
                }
                else
                {
                    Label2.Text = "Invalid User / Password";
                }
            }
        }
    }
}